package com.example.conferenceregistration.ui

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.conferenceregistration.databinding.ActivityVerificationBinding
import com.example.conferenceregistration.viewmodel.ParticipantViewModel

class VerificationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVerificationBinding
    private val viewModel: ParticipantViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVerificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        observeViewModel()
    }

    private fun setupListeners() {
        // Verify Button
        binding.btnVerify.setOnClickListener {
            verifyParticipant()
        }

        // Back Button
        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun verifyParticipant() {
        val userIdText = binding.etUserId.text.toString()

        if (userIdText.isEmpty()) {
            Toast.makeText(this, "Please enter User ID", Toast.LENGTH_SHORT).show()
            return
        }

        val userId = userIdText.toIntOrNull()
        if (userId == null) {
            Toast.makeText(this, "Invalid User ID", Toast.LENGTH_SHORT).show()
            return
        }

        // Reset UI
        binding.layoutResult.visibility = View.GONE
        binding.tvErrorMessage.visibility = View.GONE
        binding.rootLayout.setBackgroundColor(Color.WHITE)

        // Verify participant
        viewModel.verifyParticipant(userId)
    }

    private fun observeViewModel() {
        viewModel.participant.observe(this) { participant ->
            if (participant != null) {
                // User found - Display info
                binding.layoutResult.visibility = View.VISIBLE
                binding.tvErrorMessage.visibility = View.GONE

                // Display photo
                if (participant.photoPath != null) {
                    try {
                        val photoUri = Uri.parse(participant.photoPath)
                        binding.ivProfilePhoto.setImageURI(photoUri)
                    } catch (e: Exception) {
                        binding.ivProfilePhoto.setImageResource(android.R.drawable.ic_menu_gallery)
                    }
                }

                // Display name and title
                binding.tvFullName.text = "Full Name: ${participant.fullName}"
                binding.tvTitle2.text = "Title: ${participant.title}"
                binding.tvRegistrationType.text = "Registration Type: ${getRegistrationTypeText(participant.registrationType)}"

                // Set background color based on registration type
                when (participant.registrationType) {
                    1 -> binding.rootLayout.setBackgroundColor(Color.GREEN) // Full
                    2 -> binding.rootLayout.setBackgroundColor(Color.BLUE) // Student
                    3 -> binding.rootLayout.setBackgroundColor(Color.rgb(255, 165, 0)) // Orange - None
                }
            } else {
                // User not found
                binding.layoutResult.visibility = View.GONE
                binding.tvErrorMessage.visibility = View.VISIBLE
                binding.rootLayout.setBackgroundColor(Color.RED)
            }
        }

        viewModel.statusMessage.observe(this) { message ->
            if (message.contains("Not Found")) {
                // Already handled by participant observer
            }
        }
    }

    private fun getRegistrationTypeText(type: Int): String {
        return when (type) {
            1 -> "1 - Full Registration"
            2 -> "2 - Student Registration"
            3 -> "3 - No Registration"
            else -> "Unknown"
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        viewModel.resetParticipant()
    }
}