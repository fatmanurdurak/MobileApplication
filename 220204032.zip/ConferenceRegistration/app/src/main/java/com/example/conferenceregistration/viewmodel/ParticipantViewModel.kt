package com.example.conferenceregistration.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.conferenceregistration.data.database.AppDatabase
import com.example.conferenceregistration.data.entity.Participant
import com.example.conferenceregistration.data.repository.ParticipantRepository
import kotlinx.coroutines.launch

class ParticipantViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ParticipantRepository

    // LiveData for participant verification result
    private val _participant = MutableLiveData<Participant?>()
    val participant: LiveData<Participant?> = _participant

    // LiveData for operation status messages
    private val _statusMessage = MutableLiveData<String>()
    val statusMessage: LiveData<String> = _statusMessage

    init {
        val participantDao = AppDatabase.getDatabase(application).participantDao()
        repository = ParticipantRepository(participantDao)
    }

    // Yeni katılımcı kaydet
    fun insertParticipant(participant: Participant) {
        viewModelScope.launch {
            try {
                repository.insertParticipant(participant)
                _statusMessage.value = "Registration Successful!"
            } catch (e: Exception) {
                _statusMessage.value = "Registration Failed: ${e.message}"
            }
        }
    }

    // User ID'ye göre katılımcı doğrula
    fun verifyParticipant(userId: Int) {
        viewModelScope.launch {
            try {
                val result = repository.getParticipantById(userId)
                _participant.value = result
                if (result == null) {
                    _statusMessage.value = "User Not Found!"
                }
            } catch (e: Exception) {
                _statusMessage.value = "Verification Failed: ${e.message}"
                _participant.value = null
            }
        }
    }

    // Reset participant data
    fun resetParticipant() {
        _participant.value = null
        _statusMessage.value = ""
    }
}