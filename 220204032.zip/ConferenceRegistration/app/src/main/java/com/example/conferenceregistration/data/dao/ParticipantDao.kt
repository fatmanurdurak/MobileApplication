package com.example.conferenceregistration.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.conferenceregistration.data.entity.Participant

@Dao
interface ParticipantDao {

    // Yeni katılımcı ekle
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParticipant(participant: Participant)

    // User ID'ye göre katılımcı bul
    @Query("SELECT * FROM participants WHERE userId = :userId")
    suspend fun getParticipantById(userId: Int): Participant?

    // Tüm katılımcıları getir (isteğe bağlı - test için kullanılabilir)
    @Query("SELECT * FROM participants")
    suspend fun getAllParticipants(): List<Participant>
}