package com.example.conferenceregistration.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.conferenceregistration.R
import com.example.conferenceregistration.data.entity.Participant
import com.example.conferenceregistration.databinding.ActivityRegistrationBinding
import com.example.conferenceregistration.viewmodel.ParticipantViewModel
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class RegistrationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegistrationBinding
    private val viewModel: ParticipantViewModel by viewModels()
    private var photoPath: String? = null
    private var currentPhotoUri: Uri? = null

    // Camera permission launcher
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            openCamera()
        } else {
            Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    // Camera launcher
    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && currentPhotoUri != null) {
            binding.ivProfilePhoto.setImageURI(currentPhotoUri)
            photoPath = currentPhotoUri.toString()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpinner()
        setupListeners()
        observeViewModel()
    }

    private fun setupSpinner() {
        val titles = arrayOf("Prof.", "Dr.", "Student")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, titles)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTitle.adapter = adapter
    }

    private fun setupListeners() {
        // Conference Info Button
        binding.btnConferenceInfo.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example-conference.com"))
            startActivity(intent)
        }

        // Profile Photo Click
        binding.ivProfilePhoto.setOnClickListener {
            checkCameraPermission()
        }

        // Register Button
        binding.btnRegister.setOnClickListener {
            registerParticipant()
        }

        // Go to Verification Button
        binding.btnGoToVerification.setOnClickListener {
            startActivity(Intent(this, VerificationActivity::class.java))
        }
    }

    private fun checkCameraPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                openCamera()
            }
            else -> {
                requestPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun openCamera() {
        try {
            val photoFile = createImageFile()
            currentPhotoUri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                photoFile
            )
            takePictureLauncher.launch(currentPhotoUri)
        } catch (e: IOException) {
            Toast.makeText(this, "Error creating image file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun createImageFile(): File {
        val storageDir = getExternalFilesDir(null)
        return File.createTempFile(
            "PARTICIPANT_${System.currentTimeMillis()}_",
            ".jpg",
            storageDir
        ).apply {
            photoPath = absolutePath
        }
    }

    private fun registerParticipant() {
        val userIdText = binding.etUserId.text.toString()
        val fullName = binding.etFullName.text.toString()
        val title = binding.spinnerTitle.selectedItem.toString()

        val registrationType = when (binding.rgRegistrationType.checkedRadioButtonId) {
            R.id.rbFull -> 1
            R.id.rbStudent -> 2
            R.id.rbNone -> 3
            else -> 1
        }

        // Validation
        if (userIdText.isEmpty()) {
            Toast.makeText(this, "Please enter User ID", Toast.LENGTH_SHORT).show()
            return
        }

        if (fullName.isEmpty()) {
            Toast.makeText(this, "Please enter Full Name", Toast.LENGTH_SHORT).show()
            return
        }

        if (photoPath == null) {
            Toast.makeText(this, "Please take a profile photo", Toast.LENGTH_SHORT).show()
            return
        }

        val userId = userIdText.toIntOrNull()
        if (userId == null) {
            Toast.makeText(this, "Invalid User ID", Toast.LENGTH_SHORT).show()
            return
        }

        val participant = Participant(
            userId = userId,
            fullName = fullName,
            title = title,
            registrationType = registrationType,
            photoPath = photoPath
        )

        viewModel.insertParticipant(participant)
    }

    private fun observeViewModel() {
        viewModel.statusMessage.observe(this) { message ->
            if (message.isNotEmpty()) {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()

                if (message.contains("Successful")) {
                    clearForm()
                }
            }
        }
    }

    private fun clearForm() {
        binding.etUserId.text?.clear()
        binding.etFullName.text?.clear()
        binding.spinnerTitle.setSelection(0)
        binding.rgRegistrationType.check(R.id.rbFull)
        binding.ivProfilePhoto.setImageResource(android.R.drawable.ic_menu_camera)
        photoPath = null
        currentPhotoUri = null
    }
}