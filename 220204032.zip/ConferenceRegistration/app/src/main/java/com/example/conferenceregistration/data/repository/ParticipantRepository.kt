package com.example.conferenceregistration.data.repository

import com.example.conferenceregistration.data.dao.ParticipantDao
import com.example.conferenceregistration.data.entity.Participant

class ParticipantRepository(private val participantDao: ParticipantDao) {

    // Katılımcı ekle
    suspend fun insertParticipant(participant: Participant) {
        participantDao.insertParticipant(participant)
    }

    // User ID'ye göre katılımcı bul
    suspend fun getParticipantById(userId: Int): Participant? {
        return participantDao.getParticipantById(userId)
    }

    // Tüm katılımcıları getir
    suspend fun getAllParticipants(): List<Participant> {
        return participantDao.getAllParticipants()
    }
}